from transformers import pipeline
print("Loading Bahubali Model...")
qa_pipeline = pipeline(
    "question-answering",
    model="deepset/roberta-base-squad2",
    framework="pt"   # Force PyTorch
)
print("Bahubali Model Loaded Successfully")

try:
    with open("bahubali.txt", "r") as file:
        context = file.read()
except FileNotFoundError:
    print("Bahubali Story not found.")
    exit()

print("Enter your question about Bahubali (or type 'exit' to quit):\n")
while True:
    question = input("You: ")
    if question.lower() == "exit":
        print("Exiting the Bahubali Q/A. Goodbye!")
        break
    result = qa_pipeline(question=question, context=context)
    answer = result['answer']
    print(f"Bahubali Q/A: {answer}\n")